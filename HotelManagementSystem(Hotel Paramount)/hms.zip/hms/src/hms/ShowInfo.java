package hms;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ShowInfo extends javax.swing.JFrame {

    /**
     * Creates new form ShowInfo
     */
Connection con=null;
ResultSet rs=null;
PreparedStatement pst=null;
    public ShowInfo() {
        initComponents();
        show_user();
        this.setLocationRelativeTo(null);
       
       
    }
    
     public ArrayList<User> userList(){
        
        ArrayList<User> userList = new ArrayList<>();
         
         try{
           
            con = Connect.ConnectDB();
            String query1 = "SELECT * FROM driver";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query1);
            User user;
            while(rs.next()){
                user=new User(rs.getString("name"),rs.getString("gender"),rs.getString("company"),rs.getString("brand"));
                userList.add(user);
            }
            
         }
            catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
            }
         return userList;
        }
     public void show_user(){
          ArrayList<User> list = userList();
          DefaultTableModel model = (DefaultTableModel)jTable_Display_User.getModel();
          Object[] row = new Object[4];
         for(int i=0;i<list.size();i++){
             
              row[0]=list.get(i).getName();
              row[1]=list.get(i).getGender();
              row[2]=list.get(i).getCompany();
              row[3]=list.get(i).getBrand();
              model.addRow(row);
              
         }
     }
     public void clearTable()
{
    DefaultTableModel dm = (DefaultTableModel)jTable_Display_User.getModel();
    dm.getDataVector().removeAllElements();
    revalidate();
}
      public ArrayList<User> userList2(){
        
       ArrayList<User> userList2 = new ArrayList<>();
          
         try{
              con = Connect.ConnectDB();
             String query2 = "SELECT * FROM driver";
            Statement sst = con.createStatement();
            ResultSet rrs = sst.executeQuery(query2);
            User user2;
            
            while(rrs.next()){
                user2=new User(rs.getString("name"),rs.getString("gender"),rs.getString("company"),rs.getString("brand"));              
                userList2.add(user2);
            }
            
            
         }
            catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
            }
         return userList2;
        }
     public void show_user2(){
          ArrayList<User> list = userList2();
          DefaultTableModel model = (DefaultTableModel)jTable_Display_User.getModel();
          Object[] row = new Object[4];
         for(int i=0;i<list.size();i++){
              row[0]=list.get(i).getName();
              row[1]=list.get(i).getGender();
              row[2]=list.get(i).getCompany();
              row[3]=list.get(i).getBrand();
              model.addRow(row);
         }
     }
     
      public ArrayList<User> userList3(){
        
       ArrayList<User> userList3 = new ArrayList<>();
         
         try{
             con = Connect.ConnectDB();
             String query3 = "SELECT * FROM driver";
            Statement sst = con.createStatement();
            ResultSet rrs3 = sst.executeQuery(query3);
            User user3;
            
            while(rrs3.next()){
                user3=new User(rs.getString("name"),rs.getString("gender"),rs.getString("company"),rs.getString("brand"));              
                             
                userList3.add(user3);
            }
            
         }
            catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
            }
         return userList3;
        }
     public void show_user3(){
          ArrayList<User> list = userList3();
          DefaultTableModel model = (DefaultTableModel)jTable_Display_User.getModel();
          Object[] row = new Object[4];
         for(int i=0;i<list.size();i++){
              row[0]=list.get(i).getName();
              row[1]=list.get(i).getGender();
              row[2]=list.get(i).getCompany();
              row[3]=list.get(i).getBrand();
              model.addRow(row);
         }
     }
     
     
     public ArrayList<User> userList5(){
        
       ArrayList<User> userList5 = new ArrayList<>();
         
         try{
             con = Connect.ConnectDB();
             String query3 = q(txt_Search.getText());
            Statement sst = con.createStatement();
            ResultSet rrs3 = sst.executeQuery(query3);
            User user3;
            
            while(rrs3.next()){
                user3=new User(rs.getString("name"),rs.getString("gender"),rs.getString("company"),rs.getString("brand"));                          
                userList5.add(user3);
            }
            
         }
            catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
            }
         return userList5;
        }
     String q(String txtSearch){
         String sql= "SELECT * FROM driver WHERE name LIKE '%"+txtSearch+"%'";
         return sql;
     }
     public void show_user5(){
          ArrayList<User> list = userList5();
          DefaultTableModel model = (DefaultTableModel)jTable_Display_User.getModel();
          Object[] row = new Object[4];
         for(int i=0;i<list.size();i++){
              row[0]=list.get(i).getName();
              row[1]=list.get(i).getGender();
              row[2]=list.get(i).getCompany();
              row[3]=list.get(i).getBrand();
              model.addRow(row);
         }
     }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Display_User = new javax.swing.JTable();
        txt_Search = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable_Display_User.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "name", "gender", "company", "brand"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable_Display_User);

        txt_Search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_SearchKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_SearchKeyTyped(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Search:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txt_Search, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_Search, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(184, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_SearchKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_SearchKeyTyped
        // TODO add your handling code here:
        clearTable();
        show_user5();
    }//GEN-LAST:event_txt_SearchKeyTyped

    private void txt_SearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_SearchKeyReleased
        // TODO add your handling code here:
        clearTable();
        show_user5();
    }//GEN-LAST:event_txt_SearchKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ShowInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ShowInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ShowInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ShowInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ShowInfo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Display_User;
    private javax.swing.JTextField txt_Search;
    // End of variables declaration//GEN-END:variables
}
